create function get_gantt_data(p_project_id uuid DEFAULT NULL::uuid, p_start_date date DEFAULT NULL::date, p_end_date date DEFAULT NULL::date)
    returns TABLE(project_code character varying, project_name character varying, milestone_id uuid, task_name character varying, start_date date, end_date date, duration integer, department character varying, status character varying, dependencies uuid[])
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            p.project_code,
            p.project_name,
            pm.id,
            pm.l2_micro,
            pm.l2_start_date,
            pm.l2_end_date,
            (pm.l2_end_date - pm.l2_start_date)::INTEGER as duration,
            pm.department,
            pm.status,
            pm.predecessor_tasks
        FROM project_milestones pm
                 JOIN projects p ON pm.project_id = p.id
        WHERE (p_project_id IS NULL OR pm.project_id = p_project_id)
          AND (p_start_date IS NULL OR pm.l2_end_date >= p_start_date)
          AND (p_end_date IS NULL OR pm.l2_start_date <= p_end_date)
        ORDER BY pm.l2_start_date, pm.sort_order;
END;
$$;

alter function get_gantt_data(uuid, date, date) owner to laurentstaub4;

