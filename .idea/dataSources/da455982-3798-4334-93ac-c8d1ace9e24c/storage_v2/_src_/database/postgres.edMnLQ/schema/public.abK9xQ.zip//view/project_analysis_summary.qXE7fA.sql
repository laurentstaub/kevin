create view project_analysis_summary
            (id, project_code, project_name, dev_status, total_steps, completed_steps, total_assumptions,
             critical_assumptions, avg_success_rate, total_step_costs)
as
SELECT p.id,
       p.project_code,
       p.project_name,
       p.dev_status,
       count(DISTINCT ps.id)                                                    AS total_steps,
       count(DISTINCT ps.id) FILTER (WHERE ps.status::text = 'Completed'::text) AS completed_steps,
       count(DISTINCT pa.id)                                                    AS total_assumptions,
       count(DISTINCT pa.id) FILTER (WHERE pa.is_critical = true)               AS critical_assumptions,
       avg(ps.success_rate)                                                     AS avg_success_rate,
       sum(ps.cost)                                                             AS total_step_costs
FROM projects p
         LEFT JOIN project_steps ps ON p.id = ps.project_id
         LEFT JOIN project_assumptions pa ON p.id = pa.project_id
GROUP BY p.id, p.project_code, p.project_name, p.dev_status;

alter table project_analysis_summary
    owner to laurentstaub4;

