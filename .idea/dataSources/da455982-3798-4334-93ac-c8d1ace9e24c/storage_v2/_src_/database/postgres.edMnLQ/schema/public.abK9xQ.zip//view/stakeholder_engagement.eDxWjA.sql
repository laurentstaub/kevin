create view stakeholder_engagement
            (id, name, entity_id, email, phone, department, wechat, vip, gender, position, specialty, importance_level,
             stakeholder_count, d4_patients_orphacol, d3b_patients_orphacol, notes, created_at, updated_at,
             entity_name_en, classification, interaction_count, last_interaction, involved_projects)
as
SELECT s.id,
       s.name,
       s.entity_id,
       s.email,
       s.phone,
       s.department,
       s.wechat,
       s.vip,
       s.gender,
       s."position",
       s.specialty,
       s.importance_level,
       s.stakeholder_count,
       s.d4_patients_orphacol,
       s.d3b_patients_orphacol,
       s.notes,
       s.created_at,
       s.updated_at,
       e.entity_name_en,
       e.classification,
       count(DISTINCT i.id)               AS interaction_count,
       max(i.date_time)                   AS last_interaction,
       array_agg(DISTINCT p.project_code) AS involved_projects
FROM stakeholders s
         LEFT JOIN entities e ON s.entity_id = e.id
         LEFT JOIN interactions i ON s.id = ANY (i.attendees)
         LEFT JOIN projects p ON i.project_id = p.id
GROUP BY s.id, e.entity_name_en, e.classification;

alter table stakeholder_engagement
    owner to laurentstaub4;

