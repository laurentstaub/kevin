create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$SELECT '2025-02-19 13:00:36'::text AS version$$;

comment on function postgis_scripts_build_date() is 'Returns build date of the PostGIS scripts.';

alter function postgis_scripts_build_date() owner to laurentstaub4;

