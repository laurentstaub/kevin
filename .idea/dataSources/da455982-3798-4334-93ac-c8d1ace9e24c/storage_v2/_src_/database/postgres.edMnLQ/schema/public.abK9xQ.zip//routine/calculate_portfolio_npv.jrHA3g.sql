create function calculate_portfolio_npv(include_categories text[] DEFAULT NULL::text[], risk_adjusted boolean DEFAULT true) returns numeric
    language plpgsql
as
$$
DECLARE
    total_npv DECIMAL(15, 2) := 0;
BEGIN
    SELECT
        SUM(
                CASE
                    WHEN risk_adjusted THEN
                        npv_ethy *
                        CASE priority
                            WHEN '1. Very High' THEN 0.9
                            WHEN '2. High' THEN 0.75
                            WHEN '3. Medium' THEN 0.6
                            WHEN '4. Low' THEN 0.4
                            ELSE 0.5
                            END
                    ELSE npv_ethy
                    END
        )
    INTO total_npv
    FROM projects
    WHERE project_status = 'Active'
      AND (include_categories IS NULL OR category = ANY(include_categories));

    RETURN COALESCE(total_npv, 0);
END;
$$;

alter function calculate_portfolio_npv(text[], boolean) owner to laurentstaub4;

