create view projects_enhanced
            (id, project_code, project_name, project_type, dev_status, project_status, priority, therapeutic_area,
             indication_disease, api, form, category, peak_sales_ethy, npv_ethy, competition, objective, imp_loc,
             topline, cum_investment_ethy, core_pillars, nrdl, prdl, encouraged_pediatric, encouraged_generics,
             encouraged_drug_without, urgent_needed_drug, target_centers, primary_contact, last_contact, articles,
             product_profile, first_rd_121_list, notes, created_at, updated_at, categories, tags)
as
SELECT p.id,
       p.project_code,
       p.project_name,
       p.project_type,
       p.dev_status,
       p.project_status,
       p.priority,
       p.therapeutic_area,
       p.indication_disease,
       p.api,
       p.form,
       p.category,
       p.peak_sales_ethy,
       p.npv_ethy,
       p.competition,
       p.objective,
       p.imp_loc,
       p.topline,
       p.cum_investment_ethy,
       p.core_pillars,
       p.nrdl,
       p.prdl,
       p.encouraged_pediatric,
       p.encouraged_generics,
       p.encouraged_drug_without,
       p.urgent_needed_drug,
       p.target_centers,
       p.primary_contact,
       p.last_contact,
       p.articles,
       p.product_profile,
       p.first_rd_121_list,
       p.notes,
       p.created_at,
       p.updated_at,
       COALESCE(json_object_agg(d.name, c.name) FILTER (WHERE c.name IS NOT NULL), '{}'::json)      AS categories,
       COALESCE(array_agg(t.name) FILTER (WHERE t.name IS NOT NULL), ARRAY []::character varying[]) AS tags
FROM projects p
         LEFT JOIN project_categories pc ON p.id = pc.project_id
         LEFT JOIN categories c ON pc.category_id = c.id
         LEFT JOIN dimensions d ON c.dimension_id = d.id
         LEFT JOIN project_tags pt ON p.id = pt.project_id
         LEFT JOIN tags t ON pt.tag_id = t.id
GROUP BY p.id;

alter table projects_enhanced
    owner to laurentstaub4;

