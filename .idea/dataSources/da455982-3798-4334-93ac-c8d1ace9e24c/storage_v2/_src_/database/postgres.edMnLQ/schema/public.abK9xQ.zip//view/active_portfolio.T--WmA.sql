create view active_portfolio
            (id, project_code, project_name, dev_status, priority, therapeutic_area, indication_disease, category,
             npv_ethy, peak_sales_ethy, total_milestones, completed_milestones, total_interactions, last_interaction)
as
SELECT p.id,
       p.project_code,
       p.project_name,
       p.dev_status,
       p.priority,
       p.therapeutic_area,
       p.indication_disease,
       p.category,
       p.npv_ethy,
       p.peak_sales_ethy,
       count(DISTINCT pm.id)                                                    AS total_milestones,
       count(DISTINCT pm.id) FILTER (WHERE pm.status::text = 'Completed'::text) AS completed_milestones,
       count(DISTINCT i.id)                                                     AS total_interactions,
       max(i.date_time)                                                         AS last_interaction
FROM projects p
         LEFT JOIN project_milestones pm ON p.id = pm.project_id
         LEFT JOIN interactions i ON p.id = i.project_id
WHERE p.project_status::text = 'Active'::text
GROUP BY p.id;

alter table active_portfolio
    owner to laurentstaub4;

