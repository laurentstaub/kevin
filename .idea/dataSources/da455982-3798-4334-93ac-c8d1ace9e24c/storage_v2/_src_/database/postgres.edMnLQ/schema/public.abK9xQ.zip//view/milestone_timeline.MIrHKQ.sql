create view milestone_timeline
            (id, project_id, l2_micro, l1_macro, l2_start_date, l2_end_date, department, status, predecessor_tasks,
             in_charge, budget, actual_cost, attachments, notes, sort_order, is_critical_path, created_at, updated_at,
             project_code, project_name, priority, category)
as
SELECT pm.id,
       pm.project_id,
       pm.l2_micro,
       pm.l1_macro,
       pm.l2_start_date,
       pm.l2_end_date,
       pm.department,
       pm.status,
       pm.predecessor_tasks,
       pm.in_charge,
       pm.budget,
       pm.actual_cost,
       pm.attachments,
       pm.notes,
       pm.sort_order,
       pm.is_critical_path,
       pm.created_at,
       pm.updated_at,
       p.project_code,
       p.project_name,
       p.priority,
       p.category
FROM project_milestones pm
         JOIN projects p ON pm.project_id = p.id
WHERE pm.status::text = ANY
      (ARRAY ['In Progress'::character varying, 'Planned'::character varying, 'At Risk'::character varying]::text[])
ORDER BY pm.l2_start_date;

alter table milestone_timeline
    owner to laurentstaub4;

